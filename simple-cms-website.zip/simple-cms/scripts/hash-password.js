// Cach dung: npm run hash-password -- "mat-khau-cua-ban"
// Ket qua in ra la chuoi hash, dan vao bien ADMIN_PASSWORD_HASH trong file .env

const bcrypt = require("bcryptjs");

const password = process.argv[2];

if (!password) {
  console.error('Vui long nhap mat khau. Vi du: npm run hash-password -- "matkhau123"');
  process.exit(1);
}

const hash = bcrypt.hashSync(password, 12);
console.log("\nDan dong nay vao file .env, o bien ADMIN_PASSWORD_HASH:\n");
console.log(hash);
console.log("");
